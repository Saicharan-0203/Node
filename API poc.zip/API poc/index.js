const {Client, Result}=require("pg")
const express=require("express")
const app=express()
app.use(express.json())

const con=new Client({
    host:"localhost",
    user:"postgres",
    port:5432,
    password:"Saicharan@2003",
    database:"demopost"
})

con.connect().then(()=>console.log("connected"))

app.post('/postdata', (req, res) => {
  const { name, id, email_id } = req.body;
  const check_query = 'SELECT * FROM demotable WHERE email_id = $1';
  const insert_query = 'INSERT INTO demotable (name, id, email_id) VALUES ($1, $2, $3)';
  con.query(check_query, [email_id], (err, result) => {
    if (err) {
      console.error(err);
      return res.send("Error checking for duplicate");
    }

    if (result.rowCount === 0) {
      con.query(insert_query, [name, id, email_id], (err, result) => {
        if (err) {
          console.log(err)
          return res.send("Error inserting data");
        }

        console.log(result);
        res.send("POSTED DATA");
      });
    } else {
      res.send("Email already exists!");
    }
  });
});

        



app.get('/fetchdata',(req,res)=>{
    const fetch_query='SELECT * from demotable'
    con.query(fetch_query,(err,result)=>{
        if(err){
            res.send(err)
        }else{
            res.send(result.rows)
        }
    })
})


app.get('/fetchbyid/:id',(req,res)=>{
    const id=req.params.id
    const fetch_query='Select * from demotable where id=$1'
    con.query(fetch_query,[id],(err,result)=>{
        if(err){
            res.send(err)
        }else{
            res.send(result.rows)
        }

    })



})


app.put('/update/:id',(req,res)=>{
    const id=req.params.id
    const name=req.body.name
    const update_query="UPDATE demotable SET name=$1 WHERE id=$2"
    con.query(update_query,[name,id],(err,result)=>{
        if(err){
            res.send(err)
        }else{
            res.send("UPDATED")
        }
    })
})



app.delete('/delete/:id',(req,res)=>{
    const id=req.params.id
    const delete_query='DELETE FROM demotable WHERE id=$1'
    con.query(delete_query,[id],(err,result)=>{
        if(err){
            res.send(err)
        }else{
            res.send(result)
        }

    })
})

app.listen(3000,()=>{
    console.log("server running")
})
