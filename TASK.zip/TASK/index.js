const express = require('express');
const knex = require('knex')(require('./knexfile').development);
const { Model } = require('objection');

const Team = require('./models/Team');
const User = require('./models/User');
const Task = require('./models/Task');

const app = express();
app.use(express.json());

// Initialize Objection
Model.knex(knex);

// Create a team
app.post('/team', async (req, res) => {
  const team = await Team.query().insert(req.body);
  res.send(team);
});

// Create a user under a team
app.post('/user', async (req, res) => {
  const user = await User.query().insert(req.body);
  res.send(user);
});

// Create a task under a user
app.post('/task', async (req, res) => {
  const task = await Task.query().insert(req.body);
  res.send(task);
});

// Fetch all teams with users
app.get('/teams', async (req, res) => {
  const teams = await Team.query().withGraphFetched('users');
  res.send(teams);
});

// Fetch users with tasks
app.get('/users', async (req, res) => {
  const users = await User.query().withGraphFetched('tasks');
  res.send(users);
});

app.listen(8000, () => {
  console.log('Server running on port 8000');
});
