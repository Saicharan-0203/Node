module.exports = {
  development: {
    client: 'pg',
    connection: {
      host: 'localhost',
      user: 'postgres',
      password: 'Saicharan@2003',
      database: 'KNEX',
      port: 5432
    },
    migrations: {
      directory: './migrations'
    }
  }
};